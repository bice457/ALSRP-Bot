const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'mute',
    description: 'Mutes a user for a specified duration.',
    slashCommandData: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Mutes a user temporarily.')
        .addUserOption(option => option.setName('user').setDescription('User to mute').setRequired(true))
        .addIntegerOption(option => option.setName('duration').setDescription('Duration in minutes').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for mute')),

    async execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const userInput = isSlash
            ? interactionOrMessage.options.getUser('user').id
            : interactionOrMessage.content.split(' ')[1]; // Supports User ID input

        const member = interactionOrMessage.guild.members.cache.get(userInput) || 
                       interactionOrMessage.mentions.members.first() || 
                       await interactionOrMessage.guild.members.fetch(userInput).catch(() => null);

        const duration = isSlash
            ? interactionOrMessage.options.getInteger('duration')
            : parseInt(interactionOrMessage.content.split(' ')[2]);
        const reason = isSlash
            ? interactionOrMessage.options.getString('reason') || 'No reason provided.'
            : interactionOrMessage.content.split(' ').slice(3).join(' ') || 'No reason provided.';

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to mute users.', ephemeral: true });
        }
        if (!member || isNaN(duration) || duration <= 0) {
            return interactionOrMessage.reply({ content: '❌ Invalid user or duration.', ephemeral: true });
        }

        const muteTime = duration * 60 * 1000; // Convert to milliseconds
        member.timeout(muteTime, reason)
            .then(() => interactionOrMessage.reply(`✅ Muted ${member.user.tag} for ${duration} minutes. Reason: ${reason}`))
            .catch(() => interactionOrMessage.reply({ content: '❌ I do not have permission to mute this user.', ephemeral: true }));
    }
};