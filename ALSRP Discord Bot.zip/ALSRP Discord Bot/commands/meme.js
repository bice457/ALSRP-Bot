module.exports = {
    name: 'meme',
    description: 'Sends a random funny meme!',
    execute(message) {
        const memes = [
            "https://media.giphy.com/media/3ohhwhh5MeB0VRa5qg/giphy.gif",
            "https://media.giphy.com/media/5GoVLqeAOo6PK/giphy.gif",
            "https://media.giphy.com/media/26FPJGjhefSJua1L2/giphy.gif"
        ];
        const randomMeme = memes[Math.floor(Math.random() * memes.length)];
        message.reply({ content: "Here's a meme for you! 😂", files: [randomMeme] });
    }
};