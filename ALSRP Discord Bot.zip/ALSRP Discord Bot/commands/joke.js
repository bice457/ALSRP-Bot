module.exports = {
    name: 'joke',
    description: 'Tells a random joke!',
    execute(message) {
        const jokes = [
            "Why don’t skeletons fight each other? Because they don’t have the guts!",
            "Parallel lines have so much in common. It’s a shame they’ll never meet.",
            "I told my wife she should embrace her mistakes. She gave me a hug."
        ];
        const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
        message.reply(randomJoke);
    }
};