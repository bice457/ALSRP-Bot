const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const logFile = './modlogs.json';

module.exports = {
    name: 'searchlogs',
    description: 'Retrieves moderation logs for a user.',
    slashCommandData: new SlashCommandBuilder()
        .setName('searchlogs')
        .setDescription('Search moderation logs for a user.')
        .addUserOption(option => option.setName('user').setDescription('User ID or mention').setRequired(true)),

    async execute(interactionOrMessage) {
        const guild = interactionOrMessage.guild;
        if (!guild) {
            return interactionOrMessage.reply({ content: '❌ Error: This command must be used in a server.', flags: 64 });
        }

        const isSlash = !!interactionOrMessage.isCommand;
        const userInput = isSlash
            ? interactionOrMessage.options.getUser('user').id
            : interactionOrMessage.content.split(' ')[1]; // Accepts User ID input

        let member = guild.members.cache.get(userInput) || 
                     interactionOrMessage.mentions.members.first() || 
                     await guild.members.fetch(userInput).catch(() => null);

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to search logs.', flags: 64 });
        }
        if (!member) return interactionOrMessage.reply({ content: '❌ Invalid User ID or mention.', flags: 64 });

        // Load logs with error handling
        let logs = [];
        try {
            if (!fs.existsSync(logFile)) fs.writeFileSync(logFile, '[]');
            logs = JSON.parse(fs.readFileSync(logFile, 'utf-8'));
        } catch (error) {
            return interactionOrMessage.reply({ content: '❌ Error reading logs. The file may be corrupted.', flags: 64 });
        }

        // Match logs based on User ID, username, or tag
        const userLogs = logs.filter(log => log.user === member.user.id || log.user === member.user.username || log.user === member.user.tag);

        if (userLogs.length === 0) {
            return interactionOrMessage.reply({ content: `🔍 No logs found for ${member.user.tag}.`, flags: 64 });
        }

        let logMessage = `📜 **Moderation Logs for ${member.user.tag}:**\n`;
        userLogs.forEach(log => {
            logMessage += `🔢 **Log ID:** ${log.logID}  
            • **${log.type}** - *${log.reason || log.details}* (By ${log.by})\n`;
        });

        interactionOrMessage.reply(logMessage);
    }
};