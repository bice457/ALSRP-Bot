const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'ban',
    description: 'Bans a user and logs the action.',
    slashCommandData: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bans a user.')
        .addUserOption(option => option.setName('user').setDescription('User to ban').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for ban')),

    execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const userInput = isSlash
            ? interactionOrMessage.options.getUser('user')
            : interactionOrMessage.content.split(' ')[1];

        const member = interactionOrMessage.guild.members.cache.get(userInput) || 
                       interactionOrMessage.mentions.members.first();

        const reason = isSlash
            ? interactionOrMessage.options.getString('reason') || 'No reason provided.'
            : interactionOrMessage.content.split(' ').slice(2).join(' ') || 'No reason provided.';

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to ban users.', ephemeral: true });
        }
        if (!member) return interactionOrMessage.reply({ content: '❌ Invalid User ID or mention.', ephemeral: true });

        member.ban({ reason })
            .then(() => interactionOrMessage.reply(`✅ Banned ${member.user.tag} for: ${reason}`))
            .catch(() => interactionOrMessage.reply({ content: '❌ I do not have permission to ban this user.', ephemeral: true }));
    }
};