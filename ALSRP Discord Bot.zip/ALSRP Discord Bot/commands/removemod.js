const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const logFile = './modlogs.json';

module.exports = {
    name: 'removemod',
    description: 'Removes a moderation action using a Log ID.',
    slashCommandData: new SlashCommandBuilder()
        .setName('removemod')
        .setDescription('Removes a moderation action using Log ID.')
        .addUserOption(option => option.setName('user').setDescription('User affected').setRequired(true))
        .addIntegerOption(option => option.setName('logid').setDescription('Log ID of moderation action').setRequired(true)),

    execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const member = isSlash
            ? interactionOrMessage.options.getMember('user')
            : interactionOrMessage.mentions.members.first();
        const logID = isSlash
            ? interactionOrMessage.options.getInteger('logid')
            : parseInt(interactionOrMessage.content.split(' ')[2]);

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to remove moderation logs.', ephemeral: true });
        }
        if (!member || isNaN(logID)) {
            return interactionOrMessage.reply({ content: '❌ Invalid user or Log ID.', ephemeral: true });
        }

        if (!fs.existsSync(logFile)) fs.writeFileSync(logFile, '[]');
        let logs = JSON.parse(fs.readFileSync(logFile, 'utf-8'));
        const logIndex = logs.findIndex(log => log.logID === logID && log.user === member.user.tag);

        if (logIndex === -1) {
            return interactionOrMessage.reply({ content: `❌ No log found with ID **${logID}** for ${member.user.tag}.`, ephemeral: true });
        }

        const removedLog = logs.splice(logIndex, 1)[0];
        fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));

        interactionOrMessage.reply(`✅ Removed moderation action (Log ID: **${logID}**) for ${member.user.tag}.`);

        const logChannel = interactionOrMessage.guild.channels.cache.find(ch => ch.name === 'alsrp-bot-logs');
        if (logChannel) {
            logChannel.send(`🗑 **Moderation Action Removed**  
            🔢 **Log ID:** ${logID}  
            🏷 **User:** ${member.user.tag}  
            🛠 **By:** ${interactionOrMessage.user.tag}  
            📌 **Action Removed:** ${removedLog.type}`);
        }
    }
};