const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');

const requestsFile = './absence_requests.json';
const HR_CHANNEL_ID = '1358560617656619148'; // ✅ Your HR approval channel ID

module.exports = {
    name: 'reducedabsence',
    description: 'Submit a request for reduced absence, sent to HRs for approval.',
    slashCommandData: new SlashCommandBuilder()
        .setName('reducedabsence')
        .setDescription('Request reduced absence.')
        .addStringOption(option => option.setName('reason').setDescription('Reason for request').setRequired(true))
        .addStringOption(option => 
            option.setName('duration')
            .setDescription('Length of reduced absence (e.g., 1 week, 2 weeks, etc.)')
            .setRequired(true)
            .addChoices(
                { name: '1 Week', value: '1 Week' },
                { name: '2 Weeks', value: '2 Weeks' },
                { name: '1 Month', value: '1 Month' }
            )
        ),

    async execute(interaction) {
        const reason = interaction.options.getString('reason');
        const duration = interaction.options.getString('duration');
        const user = interaction.user;

        if (!fs.existsSync(requestsFile)) fs.writeFileSync(requestsFile, '[]');
        let requests = JSON.parse(fs.readFileSync(requestsFile, 'utf-8'));

        const requestID = requests.length + 1;
        const request = {
            requestID,
            userID: user.id,
            username: user.username,
            reason,
            duration,
            status: 'Pending',
            hrReason: null // Placeholder for HR decision reason
        };

        requests.push(request);
        fs.writeFileSync(requestsFile, JSON.stringify(requests, null, 2));

        const hrChannel = interaction.client.channels.cache.get(HR_CHANNEL_ID);
        if (!hrChannel) return interaction.reply({ content: '❌ HR channel not found.', ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle('📝 Reduced Absence Request')
            .setColor(0xFFD700)
            .addFields(
                { name: '👤 User:', value: user.tag, inline: true },
                { name: '📜 Reason:', value: reason, inline: false },
                { name: '⏳ Duration:', value: duration, inline: true },
                { name: '🆔 Request ID:', value: requestID.toString(), inline: true },
                { name: '📊 Status:', value: '**Pending**', inline: true }
            );

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`approve_${requestID}`)
                    .setLabel('✅ Approve')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId(`deny_${requestID}`)
                    .setLabel('❌ Deny')
                    .setStyle(ButtonStyle.Danger)
            );

        const approvalMessage = await hrChannel.send({ embeds: [embed], components: [buttons] });
        interaction.reply({ content: `✅ Your request has been sent to HRs for review.`, ephemeral: true });

        const collector = approvalMessage.createMessageComponentCollector({ time: 86400000 });

        collector.on('collect', async i => {
            if (!i.member.permissions.has('ManageMessages')) {
                return i.reply({ content: '❌ You do not have permission to approve/deny requests.', ephemeral: true });
            }

            const decision = i.customId.startsWith('approve_') ? 'Approved' : 'Denied';
            const requestID = parseInt(i.customId.split('_')[1]);

            const requestIndex = requests.findIndex(req => req.requestID === requestID);
            if (requestIndex === -1) return i.reply({ content: '❌ Request not found.', ephemeral: true });

            // 🔹 HR Input Reason Modal
            const modal = new ModalBuilder()
                .setCustomId(`reason_${requestID}`)
                .setTitle(`${decision} Reason`);

            const reasonInput = new TextInputBuilder()
                .setCustomId(`reasonInput_${requestID}`)
                .setLabel('Provide a reason for your decision')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);

            const modalRow = new ActionRowBuilder().addComponents(reasonInput);
            modal.addComponents(modalRow);

            await i.showModal(modal);

            const reasonCollector = i.awaitModalSubmit({ time: 60000 });

            reasonCollector.then(async modalInteraction => {
                const hrReason = modalInteraction.fields.getTextInputValue(`reasonInput_${requestID}`);
                const reasonLabel = decision === 'Approved' ? 'Acceptance Reason:' : 'Denial Reason:';

                requests[requestIndex].status = decision;
                requests[requestIndex].hrReason = hrReason;
                fs.writeFileSync(requestsFile, JSON.stringify(requests, null, 2));

                const updatedEmbed = EmbedBuilder.from(embed)
                    .setFields(
                        { name: '👤 User:', value: user.tag, inline: true },
                        { name: '📜 Reason:', value: reason, inline: false },
                        { name: '⏳ Duration:', value: duration, inline: true },
                        { name: '🆔 Request ID:', value: requestID.toString(), inline: true },
                        { name: '📊 Status:', value: `**${decision}**`, inline: true },
                        { name: reasonLabel, value: hrReason, inline: false }
                    );

                await modalInteraction.update({ embeds: [updatedEmbed], components: [] });

                const requester = await interaction.client.users.fetch(requests[requestIndex].userID);
                if (requester) {
                    requester.send(`📢 **Your reduced absence request (${duration}) has been ${decision}.**\n📜 **${reasonLabel}** ${hrReason}`);
                }
            }).catch(() => {
                i.reply({ content: '❌ Request timed out. No reason provided.', ephemeral: true });
            });
        });
    }
};