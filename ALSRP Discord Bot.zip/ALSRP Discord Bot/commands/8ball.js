module.exports = {
    name: '8ball',
    description: 'Answers your questions like a Magic 8-Ball!',
    execute(message) {
        const responses = [
            "Yes! Absolutely!",
            "No way!",
            "Maybe… try again later.",
            "I wouldn't count on it.",
            "Most likely!",
            "Ask again when I'm in a better mood!"
        ];
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        message.reply(`🎱 ${randomResponse}`);
    }
};