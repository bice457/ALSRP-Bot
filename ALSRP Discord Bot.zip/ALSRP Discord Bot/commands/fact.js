const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'fact',
    description: 'Get a random fun fact!',
    slashCommandData: new SlashCommandBuilder()
        .setName('fact')
        .setDescription('Fetch a random fun fact.'),

    async execute(interaction) {
        await interaction.deferReply(); // Prevents timeout while fetching data

try {
    const response = await axios.get('https://thefact.space/random');
    console.log('API Response:', response.data); // ✅ Debugging step

   const fact = response.data.text || '⚠️ Unable to retrieve a fact, try again later.';
            const embed = new EmbedBuilder()
                .setTitle('🧠 Random Fun Fact')
                .setColor(0xFFD700)
                .setDescription(`**${fact}**`)
                .setFooter({ text: 'Data sourced from TheFactSpace API' });

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error('❌ Error fetching fact:', error);
            await interaction.editReply({ content: '⚠️ Failed to retrieve a fact. Try again later.' });
        }
    }
};