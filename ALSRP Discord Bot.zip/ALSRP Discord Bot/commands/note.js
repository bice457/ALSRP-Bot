const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const logFile = './modlogs.json';

module.exports = {
    name: 'note',
    description: 'Logs a staff note about a user.',
    slashCommandData: new SlashCommandBuilder()
        .setName('note')
        .setDescription('Adds a staff note about a user.')
        .addUserOption(option => option.setName('user').setDescription('User to note').setRequired(true))
        .addStringOption(option => option.setName('details').setDescription('Details of the note').setRequired(true)),

    async execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const userInput = isSlash
            ? interactionOrMessage.options.getUser('user').id
            : interactionOrMessage.content.split(' ')[1]; // Supports User ID input

        const member = interactionOrMessage.guild.members.cache.get(userInput) || 
                       interactionOrMessage.mentions.members.first() || 
                       await interactionOrMessage.guild.members.fetch(userInput).catch(() => null);

        const details = isSlash
            ? interactionOrMessage.options.getString('details')
            : interactionOrMessage.content.split(' ').slice(2).join(' ');

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to log notes.', ephemeral: true });
        }
        if (!member) return interactionOrMessage.reply({ content: '❌ Invalid User ID or mention.', ephemeral: true });

        if (!fs.existsSync(logFile)) fs.writeFileSync(logFile, '[]');
        const logs = JSON.parse(fs.readFileSync(logFile, 'utf-8'));
        const logNumber = logs.length + 1;

        logs.push({ logID: logNumber, type: 'Note', user: member.user.tag, by: interactionOrMessage.user.tag, details, date: new Date().toISOString() });
        fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));

        interactionOrMessage.reply(`✅ Logged note for ${member.user.tag}.`);
    }
};