const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'role',
    description: 'Adds or removes multiple roles from a user.',
    slashCommandData: new SlashCommandBuilder()
        .setName('role')
        .setDescription('Manages roles for a user.')
        .addUserOption(option => option.setName('user').setDescription('User to manage').setRequired(true))
        .addStringOption(option => option.setName('roles').setDescription('Role names separated by commas').setRequired(true))
        .addStringOption(option => option.setName('action').setDescription('add/remove').setRequired(true).addChoices(
            { name: 'Add', value: 'add' },
            { name: 'Remove', value: 'remove' }
        )),

    execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const member = isSlash
            ? interactionOrMessage.options.getMember('user')
            : interactionOrMessage.mentions.members.first();
        const roleNames = isSlash
            ? interactionOrMessage.options.getString('roles').split(',').map(role => role.trim())
            : interactionOrMessage.content.split(' ').slice(2, -1).map(role => role.trim());
        const action = isSlash
            ? interactionOrMessage.options.getString('action')
            : interactionOrMessage.content.split(' ').slice(-1)[0].toLowerCase();

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to manage roles.', ephemeral: true });
        }
        if (!member || !roleNames.length || !['add', 'remove'].includes(action)) {
            return interactionOrMessage.reply({ content: '❌ Invalid user, roles, or action (use "add" or "remove").', ephemeral: true });
        }

        let successRoles = [];
        let failedRoles = [];
        roleNames.forEach(roleName => {
            const role = interactionOrMessage.guild.roles.cache.find(r => r.name.toLowerCase() === roleName.toLowerCase());
            if (!role) {
                failedRoles.push(roleName);
                return;
            }

            if (action === 'add') {
                member.roles.add(role).then(() => successRoles.push(roleName)).catch(() => failedRoles.push(roleName));
            } else {
                member.roles.remove(role).then(() => successRoles.push(roleName)).catch(() => failedRoles.push(roleName));
            }
        });

        setTimeout(() => {
            let response = `✅ **Roles ${action === 'add' ? 'added' : 'removed'} for ${member.user.tag}:** ${successRoles.join(', ')}`;
            if (failedRoles.length) response += `\n❌ Failed roles: ${failedRoles.join(', ')}`;
            interactionOrMessage.reply(response);
        }, 1000);
    }
};