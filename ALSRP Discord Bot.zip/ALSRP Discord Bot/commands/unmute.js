const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'unmute',
    description: 'Removes timeout from a muted user.',
    slashCommandData: new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('Unmutes a user.')
        .addUserOption(option => option.setName('user').setDescription('User to unmute').setRequired(true)),

    async execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const userInput = isSlash
            ? interactionOrMessage.options.getUser('user').id
            : interactionOrMessage.content.split(' ')[1]; // Supports User ID input

        const member = interactionOrMessage.guild.members.cache.get(userInput) || 
                       interactionOrMessage.mentions.members.first() || 
                       await interactionOrMessage.guild.members.fetch(userInput).catch(() => null);

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to unmute users.', ephemeral: true });
        }
        if (!member) return interactionOrMessage.reply({ content: '❌ Invalid User ID or mention.', ephemeral: true });

        // Remove timeout (unmute)
       interactionOrMessage.guild.members.edit(member, { communicationDisabledUntil: null })
            .then(() => {
                interactionOrMessage.reply(`✅ Unmuted ${member.user.tag}.`);
                
                const logChannel = interactionOrMessage.guild.channels.cache.find(ch => ch.name === 'alsrp-bot-logs');
                if (logChannel) {
                    logChannel.send(`🔊 **User Unmuted**  
                    🏷 **User:** ${member.user.tag}  
                    🛠 **By:** ${interactionOrMessage.user.tag}`);
                }
            })
            .catch(() => interactionOrMessage.reply({ content: '❌ I do not have permission to unmute this user.', ephemeral: true }));
    }
};