module.exports = {
    name: 'hello',
    description: 'Greets the user!',
    execute(message) {
        message.reply(`Hey ${message.author.username}, nice to see you! 👋`);
    }
};