const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');
const cheerio = require('cheerio');

module.exports = {
    name: 'robloxstatus',
    description: 'Check the current status of Roblox servers.',
    slashCommandData: new SlashCommandBuilder()
        .setName('robloxstatus')
        .setDescription('Fetch live Roblox server status.'),

    async execute(interaction) {
        await interaction.deferReply(); // Prevents timeout while fetching data

        try {
            const response = await axios.get('https://status.roblox.com/');
            const $ = cheerio.load(response.data);

            // Extracts the status text from the main status page
            const robloxStatus = $('.component-status').first().text().trim();
            const statusMessage = robloxStatus || '⚠️ Unable to retrieve status, check manually at https://status.roblox.com';

            const embed = new EmbedBuilder()
                .setTitle('🛠 Roblox Server Status')
                .setColor(robloxStatus.includes('Operational') ? 0x00FF00 : 0xFF0000)
                .setDescription(`**Current Status:** ${statusMessage}`)
                .setFooter({ text: 'Data sourced from Roblox Official Status Page' });

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error('❌ Error fetching Roblox status:', error);
            await interaction.editReply({ content: '⚠️ Failed to retrieve Roblox status. Try again later.' });
        }
    }
};