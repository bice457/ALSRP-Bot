const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'say',
    description: 'Repeats a message.',
    slashCommandData: new SlashCommandBuilder()
        .setName('say')
        .setDescription('Makes the bot say something.')
        .addStringOption(option => option.setName('message').setDescription('Message to send').setRequired(true)),

    execute(interactionOrMessage) {
        const isSlash = !!interactionOrMessage.isCommand;
        const messageContent = isSlash
            ? interactionOrMessage.options.getString('message')
            : interactionOrMessage.content.split(' ').slice(1).join(' ');

        if (!messageContent) {
            return interactionOrMessage.reply({ content: '❌ Please provide a message to send.', ephemeral: true });
        }

        interactionOrMessage.channel.send(messageContent);
        interactionOrMessage.reply({ content: '✅ Message sent!', ephemeral: true });
    }
};