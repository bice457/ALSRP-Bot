const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const logFile = './modlogs.json';

module.exports = {
    name: 'warn',
    description: 'Issues a warning to a user and logs it.',
    slashCommandData: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Warn a user for misconduct.')
        .addUserOption(option => option.setName('user').setDescription('User to warn').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for warning').setRequired(false)),

    async execute(interactionOrMessage) {
        const guild = interactionOrMessage.guild;
        if (!guild) {
            return interactionOrMessage.reply({ content: '❌ Error: This command must be used in a server.', flags: 64 });
        }

        const isSlash = !!interactionOrMessage.isCommand;
        const userInput = isSlash
            ? interactionOrMessage.options.getUser('user')
            : interactionOrMessage.mentions.users.first();

        if (!interactionOrMessage.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interactionOrMessage.reply({ content: '❌ You do not have permission to warn users.', flags: 64 });
        }
        if (!userInput) return interactionOrMessage.reply({ content: '❌ Invalid user mention.', flags: 64 });

        const reason = isSlash
            ? interactionOrMessage.options.getString('reason') || 'No reason provided'
            : interactionOrMessage.content.split(' ').slice(2).join(' ') || 'No reason provided';

        // Load logs with error handling
        let logs = [];
        try {
            if (!fs.existsSync(logFile)) fs.writeFileSync(logFile, '[]');
            logs = JSON.parse(fs.readFileSync(logFile, 'utf-8'));
            if (!Array.isArray(logs)) throw new Error("Invalid JSON structure.");
        } catch (error) {
            return interactionOrMessage.reply({ content: '❌ Error reading logs. The file may be corrupted.', flags: 64 });
        }

        // Create warning log entry
        const logEntry = {
            logID: logs.length + 1,
            type: 'Warn',
            user: userInput.id,
            username: userInput.username,
            tag: userInput.tag,
            by: interactionOrMessage.member.user.tag,
            reason,
            timestamp: new Date().toISOString()
        };

        logs.push(logEntry);
        try {
            fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
        } catch (error) {
            return interactionOrMessage.reply({ content: '❌ Error saving warning log.', flags: 64 });
        }

        interactionOrMessage.reply(`⚠️ **Warning issued to ${userInput.tag}**\n📜 **Reason:** ${reason}`);
    }
};