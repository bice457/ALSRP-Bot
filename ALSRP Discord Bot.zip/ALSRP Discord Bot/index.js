const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
require('dotenv').config(); // Loads environment variables

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent, // Ensure it's enabled in Discord Developer Portal
        GatewayIntentBits.GuildMembers // Required for fetching server members
    ]
});

client.commands = new Collection(); // Stores commands

// 🔹 Load commands dynamically
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
const commandsData = [];

for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.name, command);

    // Register slash command data
    if (command.slashCommandData) {
        commandsData.push(command.slashCommandData.toJSON());
    }
}

console.log(`✅ Loaded commands: ${[...client.commands.keys()].join(', ')}`);

// 🔹 Ensure environment variables exist
if (!process.env.TOKEN || !process.env.CLIENT_ID) {
    console.error('❌ Missing environment variables! Ensure TOKEN and CLIENT_ID are set in .env.');
    process.exit(1);
}

// 🔹 Register Slash Commands for Guild
const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

(async () => {
    try {
        console.log('🔄 Registering slash commands...');
        await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, '1358483737427575076'), { body: commandsData });
        console.log('✅ Slash commands registered successfully!');
    } catch (error) {
        console.error('❌ Failed to register slash commands:', error);
    }
})();

// 🔹 Bot Ready Event
client.once('ready', () => {
    console.log(`✅ Bot is online as ${client.user.tag}!`);
});

// 🔹 Handle Typed Commands (`!command`)
client.on('messageCreate', message => {
    if (!message.content.startsWith('!') || message.author.bot) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    const command = client.commands.get(commandName);

    if (!command) return;

    try {
        command.execute(message, args);
    } catch (error) {
        console.error(`❌ Error executing command "${commandName}":`, error);
        message.reply('⚠️ There was an error executing this command.');
    }
});

// 🔹 Handle Slash Commands (`/command`)
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(`❌ Error executing slash command "${interaction.commandName}":`, error);
        await interaction.reply({ content: '⚠️ There was an error executing this command.', ephemeral: true });
    }
});

// 🔹 Log in using the token from .env
client.login(process.env.TOKEN);